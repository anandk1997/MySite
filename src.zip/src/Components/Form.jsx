import React, { useEffect, useState } from 'react'
import OtherInfo from './OtherInfo';
import PersonalInfo from './PersonalInfo';
import SignUpInfo from './SignUpInfo';

const Form = () => {
    // HANDLE SUBMIT..........................................................................................................................
    // const handleSubmit = () => {
    //     console.log(text)
    //             alert('!')
    //             setText('hello')
    //             console.log(text)
    //     if (page === 0) {
    //         if (formData.email === ""){

    //         }

    //         // handleValidation();
    //         // if (formData.email === "") {
    //         //     console.log(formIsValid)
    //         //     alert('!')
    //         //     setFormIsValid(false);
    //         //     console.log(formIsValid)
    //         //     // setErrorData((prev) => {
    //         //     //     return {
    //         //     //         ...prev,
    //         //     //         emailError: "Email is empty"
    //         //     //     }
    //         //     // })
    //         // }

    //         // console.log("formData==>", formData)

    //         if (!formIsValid) {
    //             alert("Wrong Data. Data is mIssing");
    //         }

    //         else {
    //             if (page === FormTittles.length - 1) {
    //                 alert("FORM SUBMITTED")
    //             }
    //             else {
    //                 setPage((currPage) => currPage + 1);
    //             }
    //         }
    //     }

    //     if (page === 1) {
    //         handleValidation1();
    //         console.log("formData==>", formData)

    //         if (!formIsValid) {
    //             alert("Wrong Data. Data is mIssing");
    //         }

    //         else {
    //             if (page === FormTittles.length - 1) {
    //                 alert("FORM SUBMITTED")
    //             }
    //             else {
    //                 setPage((currPage) => currPage + 1);
    //             }
    //         }
    //     }

    //     if (page === 2) {

    //         handleValidation2();
    //         console.log("formData==>", formData)

    //         if (!formIsValid) {
    //             alert("Wrong Data. Data is mIssing");
    //         }

    //         else {
    //             if (page === FormTittles.length - 1) {
    //                 alert("FORM SUBMITTED")
    //             }
    //             else {
    //                 setPage((currPage) => currPage + 1);
    //             }
    //         }
    //     }
    // }

    // FORM VALIDATION.........................................................................................................................


    // const [formIsValid, setFormIsValid] = useState(true);
    // const[text,setText]=useState('hi')

    // const handleValidation = () => {
    //     if (formData.email === "") {

    //         // setErrorData((prev) => {
    //         //     return {
    //         //         ...prev,
    //         //         emailError: "Email is empty"
    //         //     }
    //         // })
    //     }

    //     if (formData.password === "") {

    //         // setErrorData((prev) => {
    //         //     return {
    //         //         ...prev,
    //         //         passwordError: "Password is empty"
    //         //     }
    //         // })

    //     }

    //     if (formData.confirmPassword != formData.password) {
    //         setFormIsValid(!formIsValid);
    //     }

    //     // setErrorData(...errorData)
    //     // emailError: "worng email")


    // }

    // const handleValidation1 = () => {

    //     if (!formData.userName == "") {
    //         setFormIsValid(false);
    //     }
    //     if (!formData.firstName == "") {
    //         setFormIsValid(false);

    //     }
    //     if (!formData.lastName === "") {
    //         setFormIsValid(false);

    //     }

    // }

    // const handleValidation2 = () => {
    //     if (!formData.nationality == "") {
    //         setFormIsValid(false);
    //     }
    //     if (formData.other == "") {
    //         setFormIsValid(false);
    //     }

    // }


    const [page, setPage] = useState(0);

    const [formData, setFormData] = useState({
        email: "",
        password: "",
        confirmPassword: "",
        firstName: "",
        lastName: "",
        userName: "",
        nationality: "",
        other: "",

    })

    const [errorData, setErrorData] = useState({});





    // SHOWING THE COMPONENTS.................................................................................................................
    const FormTittles = ["SignUp", "Personal Info", "Other"];

    const PageDisplay = () => {
        if (page === 0) {
            return <SignUpInfo formData={formData} setFormData={setFormData} errorData={errorData} setErrorData={setErrorData} />
        }
        else if (page === 1) {
            return <PersonalInfo formData={formData} setFormData={setFormData} errorData={errorData} setErrorData={setErrorData} />
        }
        else {
            return <OtherInfo formData={formData} setFormData={setFormData} errorData={errorData} setErrorData={setErrorData} />
        }
    }




    // FOR SUBMIT BUTTON..............................................................................................................
    const [isSubmit, setIsSubmit] = useState(false)

    const handleSubmit = (event) => {
        event.preventDefault();
        setPage((currPage) => currPage + 1)
        setErrorData(validate(formData));
        setIsSubmit(true)

    }



    useEffect(() => {
        // console.log(formErrors);
        if (Object.keys(errorData).length === 0 && isSubmit) {
            // console.log(formValues);
        }
    }, [errorData])






    // VALIDATION OF DATA.......................................................................................................
    const validate = (values) => {
        const errors = {}
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
        // /^[a-zA-Z0-9.! #$%&'*+/=? ^_`{|}~-]+@[a-zA-Z0-9-]+(?:\. [a-zA-Z0-9-]+)*$/

        // USERNAME VALIDATION
        // if (!values.username) {
        //   errors.username = "Username is Require"
        // }

        // EMAIL VALIDATION
        if (!values.email) {
            errors.email = "Email is Require"
        }
        else if (!regex.test(values.email)) {
            errors.email = " This is not a valid Email format"
        }

        // PASSWORD VALIDATION
        if (!values.password) {
            errors.password = "Password is Require"
        }
        else if (values.password.length < 4) {
            errors.password = "Password must be more than 4 characters"
        }
        else if (values.password.length > 10) {
            errors.password = "Password can not exceed more than 10 characters"
        }


        if (formData.confirmPassword != formData.password) {
            errors.password = "Password does not match"
        }

        return errors

    }

    return (
        <>
            <div className="form">
                <div className="progressbar">
                    <div style={{ width: page === 0 ? "33.3%" : page === 1 ? "66.6%" : "100%" }}></div>
                </div>

                <div className="form-container">

                    <div className="header">
                        <h1>{FormTittles[page]}</h1>
                    </div>

                    <div className="body">{PageDisplay()}</div>
                    {/* {console.log(PageDisplay)} */}

                    <div className="footer">
                        <button disabled={page === 0}
                            onClick={() => { setPage((currPage) => currPage - 1) }}>Prev</button>

                        <button
                            disabled={page === FormTittles.length - 1}
                            onClick={handleSubmit
                                // () => { setPage((currPage) => currPage + 1) }
                            }>{page === FormTittles.length - 1 ? "Submit" : "Next"}</button>
                    </div>

                </div>

            </div>
        </>
    )
}

export default Form
import React from 'react'
import { useState } from 'react'

const SignUpInfo = ({ formData, setFormData }) => {

    const handleChange = (event) => {
        // console.log("confirm password is called")
        // console.log("event.target==>", event.target.value);
        const { name, value } = event.target;
        console.log("name===>", name);
        setFormData((prevData) => {
            return {
                ...prevData,
                [name]: value
            }
        })
    }

    // const [errorData, setErrorData] = useState({
    //     emailError: "",
    //     passwordError: "",
    //     confirmPasswordError: "",
    //     firstNameError: "",
    //     lastNameError: "",
    //     userNameError: "",
    //     nationalityError: "",
    //     otherError: ""
    // });

    return (
        <>
            <form >
                <div className='sign-up-container'>

                    <input
                        type="email"
                        name='email'
                        placeholder='Email...'
                        value={formData.email}
                        onChange={handleChange}

                    />

                    {/* <>{errorData.emailError}</> */}

                    <input
                        type="password"
                        name='password'
                        placeholder='Password'
                        value={formData.password}
                        onChange={handleChange}

                    />

                    <input
                        type="password"
                        name='confirmPassword'
                        placeholder='Confirm Password'
                        value={formData.confirmPassword}
                        onChange={handleChange}
                    // onChange={(event) => setFormData({ ...formData, confirmPassword: event.target.value })}

                    />

                </div>
            </form>
        </>
    )
}

export default SignUpInfo
import React from 'react'

const PersonalInfo = ({ formData, setFormData, errorData, setErrorData }) => {

    const handleChange = (event) => {
        const { name, value } = event.target

        setFormData((prevData) => {
            return {
                ...prevData,
                [name]: value
            }
        })
    }

    return (
        <>
            <form >
                <div className="personal-info-container">

                    <input
                        type="text"
                        name='fname'
                        placeholder='First Name...'
                        // rules={{required:true}}
                        value={formData.fname}
                        onChange={handleChange}
                    />
                    {/* SHOWING THE ERROR */}
                    <p>{errorData.fname}</p>

                    <input
                        type="text"
                        name='lname'
                        placeholder='Last Name...'
                        // rules={{required:true}}
                        value={formData.lname}
                        onChange={handleChange}

                    />

                    <input
                        type="text"
                        name='username'
                        placeholder='Username...'
                        // rules={{required:true}}
                        value={formData.username}
                        onChange={handleChange}
                    />

                    <button type='button'>
                        
                    </button>

                </div>
            </form>

        </>
    )
}

export default PersonalInfo
import React from 'react'

const OtherInfo = ({ formData, setFormData }) => {

    const handleChange = (event) => {
        const { name, value } = event.target

        setFormData((prevData) => {
            return {
                ...prevData, [name]: value
            }
        })
    }

    return (
        <>
            <form >
                <div className="other-info-container">

                    <input
                        type="text"
                        name='nationality'
                        placeholder='Nationality...'
                        value={formData.nationality}
                        onChange={handleChange}
                    // onChange={(event) => setFormData({ ...formData, text: event.target.value })}
                    />

                    <input
                        type="text"
                        name='other'
                        placeholder='Other...'
                        value={formData.other}
                        onChange={handleChange}
                    />

                </div>
            </form>
        </>
    )
}

export default OtherInfo
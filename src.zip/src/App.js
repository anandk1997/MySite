import React from 'react'
import Form from './Components/Form'
import "./App.css"

const App = () => {
  return (
    <>
      <Form />
    </>
  )
}

export default App